from keras_frcnn.data_generators import iou as ious
import numpy as np

def get_map(pred, gt, f,imgName):
        T = {}
        P = {}
        fx, fy = f

        for bbox in gt:
            bbox['bbox_matched'] = False

        ACC = []

        pred_probs = np.array([s['prob'] for s in pred])
        box_idx_sorted_by_prob = np.argsort(pred_probs)[::-1]

        for box_idx in box_idx_sorted_by_prob:
            temp = {}
            temp["Images"] = imgName
            pred_box = pred[box_idx]
            pred_class = pred_box['class']
            pred_x1 = pred_box['x1']
            pred_x2 = pred_box['x2']
            pred_y1 = pred_box['y1']
            pred_y2 = pred_box['y2']
            pred_prob = pred_box['prob']
            if pred_class not in P:
                P[pred_class] = []
                T[pred_class] = []
            P[pred_class].append(pred_prob)
            temp["Predict"] = pred_class
            temp["confidences"] = (pred_prob)

            found_match = False
            iouStrtic = 0

            for gt_box in gt:
                gt_class = gt_box['class']
                gt_x1 = gt_box['x1']/fx
                gt_x2 = gt_box['x2']/fx
                gt_y1 = gt_box['y1']/fy
                gt_y2 = gt_box['y2']/fy
                gt_seen = gt_box['bbox_matched']
                
                if gt_class != pred_class:
                    continue
                if gt_seen:
                    continue
                iou = ious((pred_x1, pred_y1, pred_x2, pred_y2), (gt_x1, gt_y1, gt_x2, gt_y2))
                temp["gt_box"] = [gt_x1, gt_y1, gt_x2, gt_y2]
                temp["pred_box"] = [pred_x1, pred_y1, pred_x2, pred_y2]
                if iou >= 0.5: #0.5 default
                    found_match = True
                    gt_box['bbox_matched'] = True
                    iouStrtic = iou
                    break
                else:
                    iouStrtic = 0
                    continue
            if found_match:
                temp["Result"] = "TP"
            else:
                temp["Result"] = "FP"

            temp["IOU"] = round(iouStrtic , 5)
            ACC.append(temp)
            T[pred_class].append(int(found_match))

        for gt_box in gt:
            if not gt_box['bbox_matched']:
                if gt_box['class'] not in P:
                    P[gt_box['class']] = []
                    T[gt_box['class']] = []
                T[gt_box['class']].append(1)
                P[gt_box['class']].append(0)

        return ACC, len(gt)